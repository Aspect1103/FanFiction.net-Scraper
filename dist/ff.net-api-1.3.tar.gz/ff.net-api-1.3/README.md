# FanFiction.net-Scraper
Python web scraper to retrieve data from FanFiction.net
